<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

class Mws_contentbox extends Module
{
    protected $config_form = false;

    public function __construct()
    {
        $this->name = 'mws_contentbox';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'morning_in_Tbilisi';
        $this->need_instance = 1;

        /**
         * Set $this->bootstrap to true if your module is compliant with bootstrap (PrestaShop 1.6)
         */
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Content box');
        $this->description = $this->l('Place your content everywhere!');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');

        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
    }

    /**
     * Don't forget to create update methods if needed:
     * http://doc.prestashop.com/display/PS16/Enabling+the+Auto-Update
     */
    public function install()
    {
        Configuration::updateValue('TEST_TASK_PRICE_FROM', null);
        Configuration::updateValue('TEST_TASK_PRICE_TO', null);

        return parent::install() &&
		
            $this->registerHook('displayNav1');
    }

    public function uninstall()
    {
        Configuration::deleteByName('TEST_TASK_PRICE_FROM');
        Configuration::deleteByName('TEST_TASK_PRICE_TO');

        return parent::uninstall();
    }

    /**
     * Load the configuration form
     */
    public function getContent()
    {
        /**
         * If values have been submitted in the form, process.
         */
        if (((bool)Tools::isSubmit('submitMws_contentboxModule')) == true) {
            $this->postProcess();
        }

        $this->context->smarty->assign('module_dir', $this->_path);

        return $output.$this->renderForm();
    }

    /**
     * Create the form that will be displayed in the configuration of your module.
     */
    protected function renderForm()
    {
        $helper = new HelperForm();

        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->module = $this;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);

        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitMws_contentboxModule';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
            .'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');

        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFormValues(), /* Add values for your inputs */
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );

        return $helper->generateForm(array($this->getConfigForm()));
    }

    /**
     * Create the structure of your form.
     */
    protected function getConfigForm()
    {
        return array(
            'form' => array(
                'legend' => array(
                'title' => $this->l('Settings'),
                'icon' => 'icon-cogs',
                ),
                'input' => array(
                    array(
                        'col' => 3,
                        'type' => 'text',
                        'prefix' => '<i class="icon icon-dollar"></i>',
                        'desc' => $this->l('Например: 0'),
                        'name' => 'TEST_TASK_PRICE_FROM',
                        'label' => $this->l('Цена ОТ'),
                    ),
                    array(
                        'col' => 3,
                        'type' => 'text',
                        'prefix' => '<i class="icon icon-dollar"></i>',
                        'desc' => $this->l('Например: 100000'),
                        'name' => 'TEST_TASK_PRICE_TO',
                        'label' => $this->l('Цена ДО'),
                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                ),
            ),
        );
    }

    /**
     * Set values for the inputs.
     */
    protected function getConfigFormValues()
    {
        return array(
            'TEST_TASK_PRICE_FROM' => Configuration::get('TEST_TASK_PRICE_FROM', null),
            'TEST_TASK_PRICE_TO' => Configuration::get('TEST_TASK_PRICE_TO', null),
        );
    }

    /**
     * Save form data.
     */
    protected function postProcess()
    {
        $form_values = $this->getConfigFormValues();

        foreach (array_keys($form_values) as $key) {
            Configuration::updateValue($key, Tools::getValue($key));
        }
    }


    public function hookDisplayNav1()
    {
		$price_from = Configuration::get('TEST_TASK_PRICE_FROM');
		$price_to = Configuration::get('TEST_TASK_PRICE_TO');
		
		$sql = 'SELECT count(*) FROM `'._DB_PREFIX_.'product` WHERE price BETWEEN ' .$price_from. ' AND ' .$price_to;
		$results = Db::getInstance()->ExecuteS($sql);
		$count_product = intval($results[0]['count(*)']);
		
		//var_dump($count_product);
      // Назначаем переменные для шаблона smarty
      $this->context->smarty->assign([
          'TEST_TASK_PRICE_FROM' => $price_from,
          'TEST_TASK_PRICE_TO' => $price_to,
		  
		  'COUNT_PRODUCT' => $count_product
        ]);
        return $this->display(__FILE__, 'mws_contentbox.tpl');
    }
}
